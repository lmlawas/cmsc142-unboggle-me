class Letter{

	/* Letter attributes */
	char c;
	int row;
	int col;

	/* Letter constructor */
	public Letter(char c, int row, int col){
		this.c = c;
		this.row = row;
		this.col = col;
	}

}
